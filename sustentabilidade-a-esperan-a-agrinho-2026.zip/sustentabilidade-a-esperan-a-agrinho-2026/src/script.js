const player = document.getElementById("player");
const game = document.getElementById("game");
const scoreText = document.getElementById("score");
const mensagem = document.getElementById("mensagem");

let score = 0;
let playerX = 370;

document.addEventListener("keydown", (e) => {

    if(e.key === "ArrowLeft" && playerX > 0){
        playerX -= 20;
    }

    if(e.key === "ArrowRight" && playerX < 750){
        playerX += 20;
    }

    player.style.left = playerX + "px";
});

function criarItem(){

    const item = document.createElement("div");
    item.classList.add("item");

    let tipo = Math.random();

    if(tipo < 0.7){
        item.innerHTML = "🌱";
        item.dataset.valor = "1";
    }else{
        item.innerHTML = "🏭";
        item.dataset.valor = "-1";
    }

    item.style.left = Math.random()*760 + "px";
    item.style.top = "0px";

    game.appendChild(item);

    let queda = setInterval(() => {

        let topo = parseInt(item.style.top);
        item.style.top = topo + 5 + "px";

        let itemX = parseInt(item.style.left);

        if(
            topo > 420 &&
            itemX > playerX - 30 &&
            itemX < playerX + 40
        ){

            score += parseInt(item.dataset.valor);

            if(score < 0){
                score = 0;
            }

            scoreText.innerText = score;

            item.remove();
            clearInterval(queda);

            if(score >= 20){
                mensagem.innerHTML =
                "🎉 Parabéns! Você criou um Agro Forte Sustentável!";
            }
        }

        if(topo > 500){
            item.remove();
            clearInterval(queda);
        }

    },30);
}

setInterval(criarItem,1000); 