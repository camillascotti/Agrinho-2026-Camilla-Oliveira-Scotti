# Sustentabilidade é a Esperança-Agrinho 2026

A Pen created on CodePen.

Original URL: [https://codepen.io/CAMILLA-OLIVEIRA-SCOTTI/pen/bNgwaZJ](https://codepen.io/CAMILLA-OLIVEIRA-SCOTTI/pen/bNgwaZJ).

Este jogo vc utiliza seta pra direita e seta pra esquerda, pegue o máximo dee plantas possíveis e fuja das indústrias de ultra processados .

Foi utilizado o aplicativo Gemini para me auxiliar com os códigos.